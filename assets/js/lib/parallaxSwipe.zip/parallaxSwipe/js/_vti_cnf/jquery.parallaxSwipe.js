vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|10 Aug 2012 23:50:48 -0000
vti_extenderversion:SR|12.0.0.4518
vti_backlinkinfo:VX|wordpress/parallaxSwipe/parallax.html wordpress/parallaxSwipe/parallaxVertical.html
vti_author:SR|DELL-9200C-WIN7\\Rob Stewart
vti_modifiedby:SR|DELL-9200C-WIN7\\Rob Stewart
vti_timecreated:TR|10 Aug 2012 23:50:48 -0000
vti_cacheddtm:TX|10 Aug 2012 23:50:48 -0000
vti_filesize:IR|5252
vti_syncwith_torontographic.com\:21:TW|10 Aug 2012 23:50:48 -0000
vti_syncofs_torontographic.com\:21:TW|10 Aug 2012 21:02:00 -0000
